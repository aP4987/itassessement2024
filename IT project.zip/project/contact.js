<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Information</title>
  <style>
    #contactInfo {
      font-family: Arial, sans-serif;
      font-size: 16px;
    }
  </style>
</head>
<body>

<h1>Contact Information</h1>

<div id="contactInfo">
  <p id="name">Name: John Doe</p>
  <p id="email">Email: johndoe@example.com</p>
  <p id="phone">Phone: +1234567890</p>
  <p id="address">Address: 123 Main Street, City, Country</p>
</div>

<script>
  // JavaScript to display contact information
  window.onload = function() {
    // Retrieve contact information
    var contactInfo = {
      name: "John Doe",
      email: "johndoe@example.com",
      phone: "+1234567890",
      address: "123 Main Street, City, Country"
    };

    // Update HTML with contact information
    document.getElementById("name").innerHTML = "Name: " + contactInfo.name;
    document.getElementById("email").innerHTML = "Email: " + contactInfo.email;
    document.getElementById("phone").innerHTML = "Phone: " + contactInfo.phone;
    document.getElementById("address").innerHTML = "Address: " + contactInfo.address;
  };
</script>

</body>
</html>
